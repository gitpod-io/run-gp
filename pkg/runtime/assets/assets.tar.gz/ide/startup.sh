#!/bin/bash -li
cd /ide || exit
exec /ide/codehelper "$@"
