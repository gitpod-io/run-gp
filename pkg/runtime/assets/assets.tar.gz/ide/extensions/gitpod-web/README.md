# Gitpod Web integration

**Notice:** This extension is bundled with Gitpod Code. It can be disabled but not uninstalled.

## Features

This extension provides support for Gitpod Web integration.
